#!/sbin/sh
/sbin/find /system/ -type f | /sbin/grep -Fxvf /tmp/filelist | /sbin/xargs -r -t -n1 /sbin/rm -f