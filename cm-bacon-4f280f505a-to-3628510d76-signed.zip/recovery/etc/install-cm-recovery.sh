#!/system/bin/sh
if [ -f /system/etc/recovery-transform.sh ]; then
  exec sh /system/etc/recovery-transform.sh 7589888 10ac81b546147568dfd7ccf9bcb895c0433a7507 5693440 1cf0e0d80a2a848a2e22adb1f7f0ae7a061766bd
fi

if ! applypatch -c EMMC:/dev/block/platform/msm_sdcc.1/by-name/recovery:7589888:10ac81b546147568dfd7ccf9bcb895c0433a7507; then
  log -t recovery "Installing new recovery image"
  applypatch -b /system/etc/recovery-resource.dat EMMC:/dev/block/platform/msm_sdcc.1/by-name/boot:5693440:1cf0e0d80a2a848a2e22adb1f7f0ae7a061766bd EMMC:/dev/block/platform/msm_sdcc.1/by-name/recovery 10ac81b546147568dfd7ccf9bcb895c0433a7507 7589888 1cf0e0d80a2a848a2e22adb1f7f0ae7a061766bd:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
